#ifndef CHANGECLK_H
#define	CHANGECLK_H

#ifdef	__cplusplus
extern "C" {
#endif

#ifdef	__cplusplus
}
#endif


void NewClk(unsigned int);

#endif	/* CHANGECLK_H */