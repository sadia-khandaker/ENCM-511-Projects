/*
 * File:   IOs.c
 * Author: sadiakhandaker
 *
 * Created on November 26, 2022, 6:15 PM
 */


#include "xc.h"

